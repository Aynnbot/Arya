

# Vynaa Valerie | Profile

![Profile Screenshot](https://telegra.ph/file/e606e0fdac3503fa21196.jpg)

## Developer

- **Instagram**: [@vynaa_valerie](https://instagram.com/vynaa_valerie)
- **WhatsApp**: [Message Vynaa Valerie](https://wa.me/message/2MOJNXNC45Y5E1)

## Donasi

- [Saweria](https://saweria.co/vynaabot)

---

### Tentang Website

Proyek ini adalah halaman profil untuk Vynaa Valerie, seorang pengembang dan kreator konten. Halaman ini menampilkan informasi kontak utama dan tautan donasi untuk mendukung proyek.

### Cara Setting

1. **Gambar Profil**: Pastikan gambar profil disimpan di direktori `media` dengan nama `profie.jpg`.
2. **Nama**: Ganti nama yang ditampilkan di elemen `<h1>` dengan nama Anda di file `index.html`.
3. **Link Sosial Media**: Edit dan tambahkan link sosial media di file `vynaa.js` pada bagian array `links`.
4. **Tautan Donasi**: Ganti URL Saweria di bagian donasi dengan URL Anda sendiri untuk menerima donasi.

### Credits

© Recode by Vynaa Valerie
